#bin bash
sleep 500
