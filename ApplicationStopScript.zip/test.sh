#!/bin/bash
echo "hello"
echoo " hello1";
