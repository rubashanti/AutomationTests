
import json
import time
import boto3
import cfnresponse
try:
    from urllib2 import HTTPError, build_opener, HTTPHandler, Request
except ImportError:
    from urllib.error import HTTPError
    from urllib.request import build_opener, HTTPHandler, Request

#import build_opener, HTTPHandler, Request

#LOGGER = logging.getLogger()
#LOGGER.setLevel(logging.INFO)


def lambda_handler(event, context):
    if event['RequestType'] == 'Create':
           codedeploygroup=event['ResourceProperties']['CodeDeployDeploymentGroup']
           appname=event['ResourceProperties']['CodeDeployApplication']
           client = boto3.client('codedeploy')
           response = client.create_deployment(
           applicationName=appname,
           deploymentGroupName=codedeploygroup,
           deploymentConfigName='CodeDeployDefault.OneAtATime',
           description='Test',
           revision={ 'revisionType': 'S3', 's3Location':{ 'bucket': 'build111','key': 'hello111', 'bundleType': 'zip' }})
           deploymentId = response['deploymentId']
           print ("DepId is " + deploymentId)
           ## we need to check if deployment completed
           
           deployment_status = client.get_deployment ( deploymentId = deploymentId )
           status = deployment_status["deploymentInfo"]["status"]
           print ("deployment is " + status)
           send_response(event, context, "SUCCESS", {"deploymentId": deploymentId})
           
            
            
    elif event['RequestType'] == 'Update':
          send_response(event, context, "SUCCESS",{"deploymentId": "test"})
    elif event['RequestType'] == 'Delete':
          send_response(event, context, "SUCCESS",{"deploymentId": "test"})
    else:
            send_response(event, context, "FAILED",{"deploymentId": "test"})


def send_response(event, context, response_status, response_data):
    responseUrl = event['ResponseURL']
    print(responseUrl)
    PhysicalResourceId= event.get('PhysicalResourceId',"")
    print (PhysicalResourceId)
    reason = ""
    try:
        cfnresponse.send(event, context, cfnresponse.SUCCESS, response_data, PhysicalResourceId, False, reason )
     #   response = http.request('PUT', responseUrl, headers=headers, body=json_responseBody)


    except Exception as e:

        print("send(..) failed executing http.request(..):", e)




